var NAVTREE =
[
  [ "Corretor Ortografico", "index.html", [
    [ "Main Page", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ],
      [ "Deprecated List", "deprecated.html", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "AnaliseOrtografica", "struct_analise_ortografica.html", null ],
      [ "Benchmarks", "struct_benchmarks.html", null ],
      [ "COMem", "struct_c_o_mem.html", null ],
      [ "DataSLL", "struct_data_s_l_l.html", null ],
      [ "DataSLL2", "struct_data_s_l_l2.html", null ],
      [ "Dicionarios", "struct_dicionarios.html", null ],
      [ "NodeSLL", "struct_node_s_l_l.html", null ],
      [ "NodeSLL2", "struct_node_s_l_l2.html", null ],
      [ "SplayTree", "struct_splay_tree.html", null ],
      [ "SplayTreeStr", "struct_splay_tree_str.html", null ],
      [ "Stack", "struct_stack.html", null ],
      [ "Textos", "struct_textos.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ],
    [ "File List", "files.html", [
      [ "avltree.h", "avltree_8h.html", null ],
      [ "binarysearchtree.h", null, null ],
      [ "binarytree.h", "binarytree_8h.html", null ],
      [ "cocore.h", "cocore_8h.html", null ],
      [ "cohelper.h", "cohelper_8h.html", null ],
      [ "cotests.h", null, null ],
      [ "debug.h", "debug_8h.html", null ],
      [ "filesys.h", "filesys_8h.html", null ],
      [ "gui.h", "gui_8h.html", null ],
      [ "main.c", "main_8c.html", null ],
      [ "oabtree.h", "oabtree_8h.html", null ],
      [ "redblacktree.h", null, null ],
      [ "singlylinkedlist.h", null, null ],
      [ "singlylinkedlist2.h", null, null ],
      [ "splaytree.h", "splaytree_8h.html", null ],
      [ "splaytreestr.h", "splaytreestr_8h.html", null ],
      [ "stack.h", "stack_8h.html", null ]
    ] ],
    [ "Examples", "examples.html", [
      [ "C:/Users/fititnt/github/fititnt/CorretorOrtografico/source/lib/data/singlylinkedlist.h", "_c_1_2_users_2fititnt_2github_2fititnt_2_corretor_ortografico_2source_2lib_2data_2singlylinkedlist_8h-example.html", null ],
      [ "C:/Users/fititnt/github/fititnt/CorretorOrtografico/source/lib/data/singlylinkedlist2.h", "_c_1_2_users_2fititnt_2github_2fititnt_2_corretor_ortografico_2source_2lib_2data_2singlylinkedlist2_8h-example.html", null ],
      [ "C:/Users/fititnt/github/fititnt/CorretorOrtografico/source/lib/db/debug.h", "_c_1_2_users_2fititnt_2github_2fititnt_2_corretor_ortografico_2source_2lib_2db_2debug_8h-example.html", null ],
      [ "C:/Users/fititnt/github/fititnt/CorretorOrtografico/source/lib/fs/filesys.h", "_c_1_2_users_2fititnt_2github_2fititnt_2_corretor_ortografico_2source_2lib_2fs_2filesys_8h-example.html", null ]
    ] ],
    [ "Globals", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

